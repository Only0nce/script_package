# tod_robot1
Robot based on turtlebot 1 for processing premises with an UF lamp

## Installation
Firstly you must install turtlebot3, rosbridge server and web video server.
```bash
sudo apt-get install "ros-noetic-turtlebot3*"
sudo apt-get install ros-noetic-rosbridge-server
sudo apt-get install ros-noetic-web-video-server
```
then clone this repo
```bash
git clone https://github.com/bhctsntrk/TurtleBotWebControl
```

## Usage with turtlebot3 simulation

```bash
export TURTLEBOT3_MODEL=waffle
roslaunch turtlebot3_gazebo turtlebot3_world.launch
 source /opt/ros/noetic/setup.bash
roslaunch rosbridge_server rosbridge_websocket.launch
roslaunch turtlebot3_navigation turtlebot3_navigation.launch
roslaunch turtlebot3_slam turtlebot3_slam.launch
rosrun web_video_server web_video_server
rosrun robot_pose_publisher robot_pose_publisher
```
then open index.html with your browser and control your robot.