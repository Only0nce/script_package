const draggable_list = document.getElementById('draggable-list');
const check = document.getElementById('check');
// const dropdiv = document.getElementById('reset');
// const base = document.getElementById("BASE")
// const TransA = document.getElementById("TRANS_A")
// const TransB = document.getElementById("TRANS_B")
// const TransC = document.getElementById("TRANS_C")
// const pickA = document.getElementById("PICK_A")
// const pickB = document.getElementById("PICK_B")
// const pickC = document.getElementById("PICK_C")

// const pointer = [
//     'Base',
//     'Trans A',
//     'Trans B',
//     'Trans C',
//     'Entry E',
//     'Relese R',
//     'Pick A',
//     'Pick B',
//     'Pick C'
// ];
const B = 'BASE';
const TA = 'TRANS_A';
const TB = 'TRANS_B';
const TC = 'TRANS_C';
const PA = 'PICK_A';
const PB = 'PICK_B';
const PC = 'PICK_C';

// store listitems
const listItems = [];
var id = 0;

let dragStartIndex;

createList();

// const numbers = [1, 3, 110, 40, 302]
// console.log(
//     numbers.sort(function(a, b){
//         return a - b;
//     })
// );

// insert list items

function createList() {
    // [...pointer]
    //     .map(a => ({value: a, sort: Math.random() }))
    //     // .sort((a, b) => a.sort - b.sort)
    //     .map(a => a.value)
    //     .forEach((point, index) => {
    //     console.log(point);

    //     const listItem = document.createElement('li')

    //     listItem.setAttribute('data-index', index);

    //     listItem.innerHTML= `
    //         <span class="number">${index + 1}</span>
    //         <div class="draggable" draggable="true">
    //             <p class"point-name" ondragstart="drag(event)" >${point}</p>
    //             <i class="fas fa-grip-lines"></i>
    //         </div>

    //     `;

    //     listItems.push(listItem);

    //     draggable_list.appendChild(listItem);
    // });

    addEventListener();
}

function dragStart() {
    // console.log('Event', 'dragstart');
    dragStartIndex = +this.closest('li').getAttribute('data-index');
}

function dragEnter() {
    // console.log('Event', 'dragenter');
    this.classList.add('over');
}

function dragLeave() {
    // console.log('Event', 'dragleave');
    this.classList.remove('over');
}

function dragover(e) {
    // console.log('Event', 'dragover');
    e.preventDefault();
}

function dragDrop() {
    // console.log('Event', 'drop');
    const dragEndIndex = +this.getAttribute('data-index');
    swapItems(dragStartIndex, dragEndIndex);

    this.classList.remove('over');
}

//swap ;ist items that are drag and drop
function swapItems(fromIndex, toIndex) {
    const itemOne = listItems[fromIndex].querySelector('.draggable');
    const itemTwo = listItems[toIndex].querySelector('.draggable');

    listItems[fromIndex].appendChild(itemTwo);
    listItems[toIndex].appendChild(itemOne);
}

function dropdiv() {
    console.log('remove');
    const dragEnd = +this.remove('data-index');
    demove(dragStartIndex, dragEnd);
    
    this.classList.remove('over');
}

function demove(fromIndex) {
    const item = listItems[fromIndex].querySelector('.draggable');
    listItems[fromIndex].remove(item);

    console.log('remove')
}

//check the Order of list items
function checkOrder() {
    console.log('ok');
    console.log(listItems);
    // var pubmanage = new ROSLIB.Topic({
    //     ros : ros,
    //     name : '/MISSION',
    //     messageType : 'rosweb/MISSION'
    // });

    // pubmanage.publish(listItems);

    // pubmanage.subscribe(function(msg){
    //   log(msg.data) 
    // });

    // var txt_listener = new ROSLIB.Topic({
    //     ros : ros,
    //     name : '/listener',
    //     messageType : 'std_msgs/String'
    // });

    // txt_listener.subscribe(function(message) {
    //     console.log('Received message on ' + listener.name + ': ' + message.data);
    //     txt_listener.unsubscribe();
    // });
    // listItems.forEach((listItem, index) => {
        // const pointName = listItems.querySelector('.draggable').innerText.trim();
        const pointName = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        PICK_C:false,
        req: listItems
        });


        listItems;

        console.log(pointName);

        var pubmanage = new ROSLIB.Topic({
            ros : ros,
            name : '/MISSION',
            messageType : 'rosweb/MISSION'
        });
        pubmanage.publish(pointName);

        pubmanage.subscribe(function(msg){
          log(msg.data) 
        });

        var txt_listener = new ROSLIB.Topic({
            ros : ros,
            name : '/listener',
            messageType : 'std_msgs/String'
        });

        txt_listener.subscribe(function(message) {
            console.log('Received message on ' + listener.name + ': ' + message.data);
            txt_listener.unsubscribe();
        });
    // });
}

function addEventListener() {
    const draggables = document.querySelectorAll('.draggable');
    const dragListItem = document.querySelectorAll('.draggable-list li');

    draggables.forEach(draggable => {
        draggable.addEventListener('dragstart', dragStart);
    });

    dragListItem.forEach(item => {
        item.addEventListener('dragover', dragover);
        item.addEventListener('drop', dragDrop);
        item.addEventListener('dragenter', dragEnter);
        item.addEventListener('dragleave', dragLeave);
    });
}

// add drag

function base() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${B}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('BASE');
    draggable_list.appendChild(listItem);
}
function TransA() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${TA}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('TRANS_A');
    draggable_list.appendChild(listItem);
}
function TransB() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${TB}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('TRANS_B');
    draggable_list.appendChild(listItem);
}
function TransC() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${TC}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('TRANS_C');
    draggable_list.appendChild(listItem);
}
function pickA() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${PA}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('PICK_A');
    draggable_list.appendChild(listItem);
}
function pickB() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${PB}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('PICK_B');
    draggable_list.appendChild(listItem);
}
function pickC() { 
    const listItem = document.createElement('li')
    listItem.innerHTML= `
    <span class="number">${id++}</span>
    <div class="draggable" draggable="true">
        <p class"point-name" ondragstart="drag(event)" >${PC}</p>
        <i class="fas fa-grip-lines"></i>
    </div>

`;
    console.log(listItem);
    listItems.push('PICK_C');
    draggable_list.appendChild(listItem);
}

function reset(){
    window.location.replace("./index.html")
}

check.addEventListener('click', checkOrder);