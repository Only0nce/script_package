function log(msg) {$('#log').append(msg.toString() + '<br>');  }
    function start() {
        // Publishing a Topic
        // ------------------

        var pubTest = new ROSLIB.Topic({
          ros : ros,
          name : '/move_base/goal',
          messageType : 'move_base_msgs/MoveBaseActionGoal'
        });

        var p = new ROSLIB.Message({
          header: {
            seq: 3,
            stamp: {
              secs: 10276,
              nsecs: 833000000},
            frame_id: ''
          },
          goal_id: {
            stamp: {
              secs: 0,
              nsecs: 0 },
            id: ''
          },
          goal: {
            target_pose: {
              header:{
                seq: 3,
                stamp: {
                  secs: 10276,
                  nsecs: 833000000
                },
                frame_id: 'map'
              },
              pose:{
                position: {
                  x : 1.2,
                  y : -0.6,
                  z : 0.0
                },
                orientation: {
                  x: 0.0,
                  y: 0.0,
                  z: 0.0,
                  w: 1.0
                }
              }
            }
          }
          });
        pubTest.publish(p);

        // Subscribing to a Topic
        // ----------------------

        var listener = new ROSLIB.Topic({
          ros : ros,
          name : '/listener',
          messageType : 'std_msgs/String'
        });

        listener.subscribe(function(message) {
          console.log('Received message on ' + listener.name + ': ' + message.data);
          listener.unsubscribe();
        });
      }
      function entry() {
        var pubTest = new ROSLIB.Topic({
            ros : ros,
            name : '/MISSION',
            messageType : 'rosweb/MISSION'
          });

        pubTest.subscribe(function(msg){
          log(msg.data) 
        });

        var txt_listener = new ROSLIB.Topic({
          ros : ros,
          name : '/listener',
          messageType : 'std_msgs/String'
        });


        txt_listener.subscribe(function(message) {
          console.log('Received message on ' + listener.name + ': ' + message.data);
          txt_listener.unsubscribe();
        });

      }

      function mission() {
        var mission = document.getElementById("mission");
        
        if(mission == "base") {
          const missionc = document.getElementById('mission');
          console.log(missionc.value);

          var pubTest = new ROSLIB.Topic({
            ros : ros,
            name : '/MISSION',
            messageType : 'rosweb/MISSION'
          });

          pubTest.subscribe(function(msg){
          log(msg.data) 
        });

          var txt_listener = new ROSLIB.Topic({
            ros : ros,
            name : '/listener',
            messageType : 'std_msgs/String'
          });


          txt_listener.subscribe(function(message) {
            console.log('Received message on ' + listener.name + ': ' + message.data);
            txt_listener.unsubscribe();
          });
          form.reset();
        }
      }