function entry() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:true,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }
  function release() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:true,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }

  function basego() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: true,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }

  function TransAgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:true,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }
  function TransBgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:true,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }
  function TransCgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:true,
        PICK_A:false,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }

  function pickAgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:true,
        PICK_B:false,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }
  function pickBgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:true,
        PICK_C:false,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }
  function pickCgo() {
    var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      var p = new ROSLIB.Message({
        BASE: false,
        ENTRY:false,
        RELEASE:false,
        TRANS_A:false,
        TRANS_B:false,
        TRANS_C:false,
        PICK_A:false,
        PICK_B:false,
        PICK_C:true,
        req: []
      });

      pubTest.publish(p);

    pubTest.subscribe(function(msg){
      log(msg.data) 
    });

    var txt_listener = new ROSLIB.Topic({
      ros : ros,
      name : '/listener',
      messageType : 'std_msgs/String'
    });


    txt_listener.subscribe(function(message) {
      console.log('Received message on ' + listener.name + ': ' + message.data);
      txt_listener.unsubscribe();
    });

  }

  function mission() {
    console.log('ok');
    var mission = document.getElementById("mission");
    
    if(mission == "base") {
      const missionc = document.getElementById('mission');
      console.log(missionc.value);

      var pubTest = new ROSLIB.Topic({
        ros : ros,
        name : '/MISSION',
        messageType : 'rosweb/MISSION'
      });

      pubTest.subscribe(function(msg){
      log(msg.data) 
    });

      var txt_listener = new ROSLIB.Topic({
        ros : ros,
        name : '/listener',
        messageType : 'std_msgs/String'
      });


      txt_listener.subscribe(function(message) {
        console.log('Received message on ' + listener.name + ': ' + message.data);
        txt_listener.unsubscribe();
      });
      form.reset();
    }
  }